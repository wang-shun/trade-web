/*
 * Copyright (c) 2016.
 */

package com.centaline.parportal.demo.entity;

/**
 * Created by linjiarong on 2016/10/12.
 */
public class Demo {
    private Integer pkid;

    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getPkid() {

        return pkid;
    }

    public void setPkid(Integer pkid) {
        this.pkid = pkid;
    }
}
