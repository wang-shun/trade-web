package com.centaline.parportal.mobile.login.service;

public interface PropertiesGetService {
	Boolean isUseADLogin();
	
	public String getAgentImgUrl();
}
