package com.centaline.parportal.demo.service;

import org.springframework.stereotype.Service;

/**
 * Created by linjiarong on 2016/10/12.
 */
public interface DemoService {
    public String helloworld();
    String sayHi(String realName);
}
