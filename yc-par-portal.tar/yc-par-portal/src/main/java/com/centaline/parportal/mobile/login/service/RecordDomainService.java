package com.centaline.parportal.mobile.login.service;

public interface RecordDomainService {
	
	public String getRecordDomain();
	
	public String getCustomRecordDomain();
}
